package com.example.tugasstarbuck.identity

import android.graphics.drawable.AnimationDrawable
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.example.tugasstarbuck.R
import kotlinx.android.synthetic.main.activity_login.*


class LoginActivity : AppCompatActivity() {
    /**
     * membuat login :
     * step 1 : membuat shape untuk editText dan Button di drawable
     * step 2 : membuat activtiy layout login terlebih dulu
     * step 3 : tambahkan use permisson internet pada manifest
     * step 4 :
     */

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        //mengaktifkan gradient_list
        val animationDrawable2 = login.getBackground() as AnimationDrawable
        animationDrawable2.setEnterFadeDuration(5000)
        animationDrawable2.setExitFadeDuration(5000)
        animationDrawable2.start()
    }
}
