package com.example.tugasstarbuck.identity.ApiHelper

import retrofit2.Retrofit

class RetrofitClient {

    private var retrofit: Retrofit? = null

    Retrofit getClient(baseUrl : String){

    }

}